package Parte1;

import Parte1.Model.*;
import java.util.ArrayList;
import java.util.Scanner;

public class JugueteService {

    //ArrayList: Lista donde guardamos todos los jugetes registrados
    private ArrayList<Juguetes> inventario=new ArrayList<>();

    //Vector: Clasificaciones por edad
    private String[]clasificaciones={"0-3", "4-7", "8-12", "+13"};

    //Agrega el objeto jugetes existente al inventario
    public void productoExistente (Juguetes j){
        inventario.add(j);
    }

    //scanner para capturar la entrada del usuario por la consola
    private Scanner scanner=new Scanner(System.in);

    //Metodo para registrar nuevo juguete
    public void registrarProducto(){
        System.out.println("Seleccione el tipo de juguete por favor: \n" +
                "1. Peluche\n" +
                "2. Electrónico\n" +
                "3. Educativo");
        int opcion=scanner.nextInt();
        scanner.nextLine();
        //Limpiar buffer

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Precio: ");
        double precio = scanner.nextDouble();
        System.out.print("Cantidad del stock: ");
        int cantidad = scanner.nextInt();

        //Mostrar opciones de clasificación usando el vector
        System.out.println("Seleccione clasificación por edad:");
        for (int i = 0; i < clasificaciones.length; i++) {
            System.out.println((i+1)+"."+clasificaciones[i]);
        }
        int clasificacionIndex=scanner.nextInt();
        scanner.nextLine(); //Limpiar buffer
        String clasificacionEdad=clasificaciones[clasificacionIndex-1];

        switch (opcion){
            case 1:
                System.out.println("¿El peluche es grande o pequeño? ");
                String tamaño=scanner.nextLine();
                inventario.add(new Peluches(nombre, precio, cantidad, clasificacionEdad,tamaño));
                break;
            case 2:
                System.out.println("¿Tiene luces? (sí/no) ");
                String tieneLuces=scanner.nextLine();
                inventario.add(new Electronicos(nombre, precio, cantidad, clasificacionEdad, tieneLuces.equalsIgnoreCase("sí")));
                break;
            case 3:
                System.out.println("Tema educativo: ");
                String tema=scanner.nextLine();
                inventario.add(new Educativos(nombre, precio, cantidad, clasificacionEdad,tema));
                break;
            default:
                System.out.println("Opción inválida...Intente de nuevo");
        }
        System.out.println("¡Juguete registrado!");

    }

    //Mostrar todos los juguetes registrados
    public void mostrarProducto(){
        if (inventario.isEmpty()){
            System.out.println("No hay productos registrados");
            return;
        }
        System.out.println("━━━━━━✧Lista de Juguetes✧━━━━━━");
        for (Juguetes j:inventario){
            j.mostrarInformacion();
        }
        System.out.println();
    }

    //Buscar productos por nombre
    public void buscarProducto(){
        System.out.println("Por favor ingrese el nombre del producto que busca: ");
        String nombre=scanner.nextLine();

        boolean encontrado=false;
        for (Juguetes j:inventario){
            if (j.getNombre().toLowerCase().contains(nombre.toLowerCase())){
                j.mostrarInformacion();
                encontrado=true;
            }
        }
        if (!encontrado){
            System.out.println("No se encontró ningún producto con ese nombre...Por favor verifique");
        }
    }
}
